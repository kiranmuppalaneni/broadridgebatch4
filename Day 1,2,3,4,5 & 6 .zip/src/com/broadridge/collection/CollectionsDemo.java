package com.broadridge.collection;

import java.util.Collection;
import java.util.TreeSet;

public class CollectionsDemo {

	public static void main(String[] args) {

		// Collection collection = new ArrayList();

		// Collection collection = new HashSet();
		//
		// collection.add(1);
		// collection.add("Hello");
		// // collection.add(new SalaryAccount(1001,"cust1",10000,"addr1"));
		// // collection.add(new SalaryAccount(1002,"cust2",20000,"addr2"));
		// // collection.add(new Employee(1,"emp1","emp1@mail.com","proj1",12121));
		// collection.add(1);
		// collection.add(1);
		// collection.add(1);
		// collection.add("Hello");
		// // collection.add(new SalaryAccount());
		// // collection.add(new Employee(2,"emp2","emp2@mail.com","proj2",12454121));
		// collection.add(1);
		// collection.add(1);
		// collection.add(1);
		//
		// System.out.println(collection);
		//
		// boolean contains = collection.contains("Hello");
		// System.out.println(contains);
		//
		// boolean remove = collection.remove("Hello");
		// System.out.println(remove);
		//
		// System.out.println(collection);
		//
		// collection.clear();
		// System.out.println(collection);

		// Collection collection = new TreeSet();
		//
		// collection.add("Hello");
		// collection.add("World");
		// collection.add("Java");
		// collection.add("Broad Ridge");
		// collection.add("Hello");
		// collection.add("Collection");
		// collection.add("India");
		// collection.add("World");
		//
		// System.out.println(collection);
		//
		// boolean contains = collection.contains("Hello");
		// System.out.println(contains);
		//
		// boolean remove = collection.remove("Hello");
		// System.out.println(remove);
		//
		// System.out.println(collection);
		//
		// collection.clear();
		// System.out.println(collection);

		Collection<String> collection = new TreeSet<>();// generics , duplicates eliminated,sorting
		
		collection.add("Hello");
		collection.add("World");
		collection.add("Java");
		collection.add("Broad ridge");
		collection.add("World");
		collection.add("Java");
		collection.add("Broad ridge");
		
		
		for(String str :collection) {
			System.out.println(str  + "  "+ str.length());
		}

	}
}
