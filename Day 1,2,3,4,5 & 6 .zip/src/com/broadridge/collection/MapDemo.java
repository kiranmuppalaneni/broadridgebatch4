package com.broadridge.collection;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {

		Map<Integer,String> map = new HashMap<>();
		map.put(1001, "emp1001");
		map.put(1002, "emp1002");
		map.put(1004, "emp1004");
		map.put(1003, "emp1003");
		map.put(1001, "emp1006");
		
		System.out.println(map);
		String val = map.get(1004);
		System.out.println(val);
		
		System.out.println(map.keySet());
		System.out.println(map.values());
		
		map.remove(1004);
		System.out.println(map);
		
		System.out.println(map.containsKey(1001));
				
	}
}
