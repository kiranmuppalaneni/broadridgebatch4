package com.broadridge.oop;

public class HDFCATM implements ATM {

	@Override
	public void withdraw(double amount) {
		System.out.println("HDFC Withdraw");

	}

	@Override
	public void checkBalance() {
		System.out.println("HDFC Check Balance");

	}

	@Override
	public void getMiniStatement() {
		System.out.println("HDFC MiniStatement");

	}

}
