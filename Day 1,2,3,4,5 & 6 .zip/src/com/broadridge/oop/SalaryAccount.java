package com.broadridge.oop;

public class SalaryAccount extends Account {

	public SalaryAccount() {

	}

	public SalaryAccount(long accountNumber, String customeName, double balance, String address) {
		super(accountNumber, customeName, balance, address);
	}

	public void depositSalary() {
		System.out.println("Salary deposited");
	}

	public void applyCreditCard() {
		System.out.println("Salary deposit");
	}

	public double getInterest() {
		return getBalance() * 1.1;
	}

	


	
}
