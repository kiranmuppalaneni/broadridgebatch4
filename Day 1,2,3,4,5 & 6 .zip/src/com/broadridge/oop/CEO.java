package com.broadridge.oop;

public class CEO {
   public String name;
   public long contantNumber;
   public String mail;
   public int shares;
}
