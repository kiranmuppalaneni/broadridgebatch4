package com.broadridge.oop;
//1. In super class abstract methods.
//2. If a class has at least one abstract method the class must be declared as abstract. 
//3. If a class does not have any abstract methods the class may or may not be declared as abstract. 
//4. We can't create the object for abstract class. but we can have variable declared.
//5. All the methods must be using sub class object.
public abstract class Account {
	// instance variable // data
	private long accountNumber;
	private String customeName;
	private double balance;
	private String address;

	// [A.M] [N A.M] returntype methodname([arguments])[throws][{

	// body
	// }]
	// void add(int i , int j){
	// i+j;
	// }

	public Account() {
		// 1..n
		System.out.println("No Arg Account class constructor is invoked********");
		accountNumber = 1001;
		customeName = "cust1";
		balance = 10000.00;
		address = "addr1";
	}

	public Account(long no, String name, double bal, String addr) { // write
		System.out.println("Arg Account class constructor is invoked********");
		accountNumber = no;
		customeName = name;
		balance = bal;
		address = addr;
	}

//	public void createAccount(long no, String name, double bal, String addr) { // write
//		accountNumber = no;
//		customeName = name;
//		balance = bal;
//		address = addr;
//	}

	public void accountMethod() {
		// 1..n
		System.out.println("Account class method is invoked");
	}
	public void getAccount() {
		System.out.println(accountNumber); // reading and printing
		System.out.println(customeName);
		System.out.println(balance);
		System.out.println(address);
	}

	public double getBalance() {
		return balance;
	}

	public double deposit(double amount) {
		balance = balance + amount;
		return balance;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getAddress() {
		return address;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double withdraw(double amount) {
		balance = balance - amount;
		return balance;
	}

	public void setAddress(String addr) {
		address = addr;
	}
	
	public abstract double getInterest() ;
}
