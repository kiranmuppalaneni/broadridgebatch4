package com.broadridge.oop;

// Creating an structure
public class Name {
	public String firstName;
	public String lastName;
	public String middleName;	
}
