package com.broadridge.oop;

// 26 Employee details
// User defined datatype
public class Employee {
	public int employeeId;
	public String name;
	public String email;
	public String project; // name,startdate,budget,resources
	public long phone;

	public Employee(int employeeId, String name, String email, String project, long phone) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.email = email;
		this.project = project;
		this.phone = phone;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", email=" + email + ", project=" + project
				+ ", phone=" + phone + "]";
	}
	
	

}
