package com.broadridge.oop;

public class Address {
	public String houseNo;
	public String city;
	public String streetName;
	public int pincode;
}
