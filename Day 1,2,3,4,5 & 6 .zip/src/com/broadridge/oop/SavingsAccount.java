package com.broadridge.oop;

public  class SavingsAccount extends Account{
	// instance variable // data
	private double minimumBalance;

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minBalance) {
		minimumBalance = minBalance;
	}

	@Override
	public double getInterest() {
		// TODO Auto-generated method stub
		return getBalance()*2.5;
	}
	
	
}
