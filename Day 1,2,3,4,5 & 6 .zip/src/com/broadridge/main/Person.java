package com.broadridge.main;

import com.broadridge.oop.ATM;
import com.broadridge.oop.HDFCATM;
import com.broadridge.oop.SBIATM;

public class Person {
   public static void main(String[] args) {
	
	   ATM atm = new HDFCATM();
	   atm.checkBalance();
	   atm.withdraw(2000);
	   atm.getMiniStatement();
	   
	   atm = new SBIATM();
	   atm.checkBalance();
	   atm.withdraw(2000);
	   atm.getMiniStatement();
	   
	   SBIATM sbiatam = new SBIATM();
	   sbiatam.checkBalance();
	   
}
}
