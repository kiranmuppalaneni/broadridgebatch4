package com.broadridge.main;

import com.broadridge.oop.Employee;
import com.broadridge.oop.Name;

public class EmployeeMain {
	public static void main(String[] args) {
		
		int      i      =  10;
		int[]    j      =  {1,2,3,66,54,5767,565};
		Employee emp    =  new Employee();
		
		Employee emp1 = new Employee();

		System.out.println(emp1.employeeId);
		System.out.println(emp1.email);
		System.out.println(emp1.phone);
		System.out.println(emp1.name);
		System.out.println(emp1.project);
		
		emp1.employeeId = 3456;
		emp1.email = "name1@mail.com";
		emp1.name = "name1";
		
		emp1.phone = 1234456;
		emp1.project = "projt1";
		
		System.out.println(emp1.employeeId);
		System.out.println(emp1.email);
		System.out.println(emp1.phone);
		System.out.println(emp1.name);
		System.out.println(emp1.project);
		
		emp1.project ="project2";
		System.out.println(emp1.project);
		
		Employee emp2  = new Employee();
		System.out.println("************");
		System.out.println(emp2.employeeId);
		System.out.println(emp2.email);
		System.out.println(emp2.phone);
		System.out.println(emp2.name);
		System.out.println(emp2.project);
		
		emp2.employeeId = 1234;
		emp2.name = "name2";
		emp2.email = "name2@mail.com";
		emp2.phone = 343434;
		emp2.project = "projt3";
		
		System.out.println(emp2.employeeId);
		System.out.println(emp2.email);
		System.out.println(emp2.phone);
		System.out.println(emp2.name);
		System.out.println(emp2.project);
		
	}
}
