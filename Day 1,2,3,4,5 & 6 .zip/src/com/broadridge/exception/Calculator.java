package com.broadridge.exception;

public class Calculator {

	public double sqrt(double d)throws WrongNumberException {
		if (d < 0) {
			throw new WrongNumberException("Number can't be less than zero");
		} else {
			return Math.sqrt(d);
		}
	}
}
