package com.broadridge.exception;

public class WrongNumberException extends Exception{

	public WrongNumberException() {
		// TODO Auto-generated constructor stub
	}
	
	public WrongNumberException(String message){
		super(message);
	}
}
