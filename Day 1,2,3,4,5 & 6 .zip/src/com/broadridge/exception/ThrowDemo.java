package com.broadridge.exception;

// try, catch,finally,throw,throws
public class ThrowDemo {

	public static void main(String[] args) {

		System.out.println("Main method start ");
		//
		//
		//// throw new WrongNumberException();
		// int i = 10/0;
		//
		//// throw new ArithmeticException("/by zero");
		//
		//// String str = new String("Hello World");
		//// char c = str.charAt(50);
		//
		//// System.out.println("Main method end " + c);

		Calculator c = new Calculator();

		double d;

		try {
			d = c.sqrt(-12);
			System.out.println(d);
		} catch (WrongNumberException e) {
			System.out.println(e);
		} // checked exception

		System.out.println("Main End");
	}

}
