package com.broadridge.exception;

public class ExceptionDemo1 {

	public static void main(String[] args) {
		System.out.println("Main method start ");
		ExceptionDemo1 ed1 = new ExceptionDemo1();
		ed1.method1(); //java.lang.NullPointerException
		System.out.println("Main method end ");
	}

	public void method1() {
		System.out.println("Method1 method start");
		method2();
		System.out.println("Method1 method end");
	}

	public void method2() {
		System.out.println("Method2 method start");
		int i = 10 / 0;  //java.lang.ArithmeticException
		System.out.println("Method2 method end");

	}

}
