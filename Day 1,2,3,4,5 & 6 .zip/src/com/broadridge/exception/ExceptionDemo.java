package com.broadridge.exception;

// try, catch,finally,throw,throws
public class ExceptionDemo {

	public static void main(String[] args) {

		System.out.println("Main method start");

		try {
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
			int i = a / b; // jvm has created ArithmeticException object
			System.out.println("I = " + i);
		}
		catch (ArithmeticException a) {
			System.out.println("Exception caught , Number can't be zero "+a);
		}
//		catch (ArrayIndexOutOfBoundsException b) {
//			System.out.println("Exception caught , Provide 2 values "+b);
//		}
		catch (NumberFormatException c) {
			System.out.println("Exception caught , Provide 2 integer values "+c );
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught , Unknown Exception "+e );
		}
		finally {
			System.out.println("finally Complusary executed");
		}
		

		System.out.println("Main method end");

	}

}
