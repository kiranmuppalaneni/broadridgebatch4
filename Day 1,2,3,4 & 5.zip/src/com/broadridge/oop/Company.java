package com.broadridge.oop;

public class Company {
	public String companyName;
	public int companyNumber;
    public CEO ceoDetails;
    public Employee[] employeeDetails;
}
