package com.broadridge.oop;

public class SBIATM implements ATM {

	@Override
	public void withdraw(double amount) {
		System.out.println("SBI Withdraw");

	}

	@Override
	public void checkBalance() {
		System.out.println("SBI Check Balance");

	}

	@Override
	public void getMiniStatement() {
		System.out.println("SBI MiniStatement");

	}

}
