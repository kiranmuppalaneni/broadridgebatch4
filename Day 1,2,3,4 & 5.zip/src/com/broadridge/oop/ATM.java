package com.broadridge.oop;

public interface ATM {
     public abstract void withdraw(double amount);
     public void checkBalance();
     void getMiniStatement();
}
