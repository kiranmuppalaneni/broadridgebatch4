package com.broadridge.main;

import java.util.Scanner;

import com.broadridge.oop.Account;
import com.broadridge.oop.SalaryAccount;
import com.broadridge.oop.SavingsAccount;

//USER -> ATM -> withdraw the money -> check balance 
public class AccountMain {
	public static void main(String[] args) {
		// new - allocate memory for fields of the class
		// It will call a special method(constructor)
		// Account acc1 = new Account();
		// acc1.getAccount();
		// // // 1. Create an object for the class
		// // // 2. use the object reference and invoke method by its name
		// // // 3. if a method takes arguments you must pass the values
		// // acc1.createAccount(1001, "cust1", 10000.00, "addr1");
		// // acc1.getAccount();
		// //
		// // System.out.println("**************************");
		// //
		// Account acc2 = new Account(1002, "cust2", 20000.00, "addr2");
		// // acc2.createAccount(1002, "cust2", 20000.00, "addr2");
		// acc2.getAccount();
		//
		// Account acc3 = new Account(1003, "cust3", 30000.00, "addr3");
		// // acc2.createAccount(1002, "cust2", 20000.00, "addr2");
		// acc3.getAccount();
		//
		// // acc2.balance = 250000; // how many times read/write.. n
		// // acc2.getAccount();
		//
		// // acc1.getBalance();
		// // acc2.getBalance();
		//
		// // acc2.deposit(2300);
		// // double balance = acc1.getBalance();
		// // if (balance > 10000) {
		// // acc1.withdraw(1200);
		// // }
		// // acc1.getBalance();
		// //
		// // acc1.setAddress("addr100");
		// // acc1.getAccount();
		//
		// // System.out.println(acc1.getBalance());
		// // double existingBalance = acc1.withdraw(3000);
		// // System.out.println(acc1.getBalance());
		//
		// Scanner scan = new Scanner(System.in);
		// System.out.println("Enter Password");
		// String password = scan.next();
		// // if string length > 8 then i will make him login
		//
		// int length = password.length();
		// if (length > 8) {
		// System.out.println("Login Succesful");
		// }else
		// System.out.println("Login failure");
		//
		//
		// System.out.println(10);

		SalaryAccount salAccount = new SalaryAccount();
		salAccount.setBalance(20000);
		// salAccount.depositSalary();
		// salAccount.getAccount();
		salAccount.withdraw(2000);
		System.out.println(salAccount.getInterest());

		SavingsAccount savAccount = new SavingsAccount();
		savAccount.setBalance(200000);
		// savAccount.getMinimumBalance();
		// savAccount.getAccount();
		System.out.println(savAccount.getInterest());

		String str = new String("Hello World");

		String str1 = str.concat(" Java");

		int length = str1.concat(" Welcome").toUpperCase().toLowerCase().substring(4).length();

	}
}
