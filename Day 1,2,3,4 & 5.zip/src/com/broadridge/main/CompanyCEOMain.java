package com.broadridge.main;

import com.broadridge.oop.CEO;
import com.broadridge.oop.Company;

public class CompanyCEOMain {
	public static void main(String[] args) {
		Company c1 = new Company();
		c1.companyName = "Broad ridge";
		c1.companyNumber = 43443434;

		CEO ceo1 = new CEO();
		ceo1.name = "CEO1";
		ceo1.contantNumber = 121212112;
		ceo1.mail = "ceo1@broadridge.com";
		ceo1.shares = 4000;

		c1.ceoDetails = ceo1;

		
		
		CEO ceo2= new CEO();
		ceo2.name = "CEO2";
		ceo2.contantNumber = 4533543;
		ceo2.mail = "ceo1@company.com";
		ceo2.shares = 4000;
		
		Company c2 = new Company();
		c2.companyName = "XYZ";
		c2.companyNumber = 454545;
		
		c2.ceoDetails = ceo2;

	}
}
